import numpy as np
import numpy_financial as npf 
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.ticker as mtick
import seaborn as sns

# Universal Variables
income = 200000
married = True          # *** Future Improvement: Build out tax calculations based on marital status and income
inflation_exp = 0.03    # Expected inflation rate for general cost increases
time_horizon = 5        # Years until planning to move

# Rental Variables
current_rent = 3500
rent_incr_exp = min(inflation_exp, 0.06)  # *** Improvement: Look into CA rent control laws for accurate cap
renter_ins = 0.01        # Renter’s insurance as a percentage of rent
sec_deposit = 0.2        # Security deposit as a percentage of rent
invest_yield_exp = 0.05  # Expected annual return on investments from savings

# Purchase Variables
home_price = 650000
down_pmt = 0.00          # Down payment as a percentage of home price
int_rate = 0.0278        # Interest rate for mortgage
term = 30                # Loan term in years

hoa = 0                   # Monthly HOA fee (if applicable)
prop_tax = 0.0122         # Property tax rate as a percentage of assessed home value
home_ins = 0.002          # Home insurance rate as a percentage of home price
home_repairs = 0.01       # Estimated repairs & improvement costs as a percentage of home price

loan_type_options = ['Conventional', 'VA', 'FHA', 'USDA']
loan_type = loan_type_options[1]  # *** Improvement: Consider adding an interactive dropdown for loan selection

fees_out_of_pocket = False       # Determines if VA funding fee/PMI costs are paid out of pocket
VA_ff = True                     # VA funding fee waiver (if service-disabled)

price_appr_exp = 0.03            # Expected annual home price appreciation rate
assd_incr_exp = 0.02             # Expected annual assessed value increase (capped at 2% in CA)

closing_cost = 0.03              # Closing costs as a percentage of home price (both sale and purchase)
realtor_fee = 0.06               # Realtor fee (applied at sale)

rent_after_move = True           # *** Improvement: Add option to calculate NPV of rental income if not selling home

# Security deposit calculation
sec_deposit = current_rent * sec_deposit

# Rental Cost Functions
def annual_rental_cost(yrs_rented):
    """
    Calculate the adjusted annual rental cost for a given year, including insurance.
    """
    adj_rent = 12 * (current_rent * ((1 + rent_incr_exp) ** yrs_rented))
    adj_total = adj_rent + (adj_rent * renter_ins)
    adj_total += sec_deposit if yrs_rented == 0 else 0
    return adj_total

def gross_rental_cost(yrs_rented):
    """
    Calculate cumulative rental cost over a specified number of years.
    """
    result = sec_deposit
    for i in range(yrs_rented):
        adj_rent = 12 * (current_rent * ((1 + rent_incr_exp) ** i))
        adj_total = adj_rent + (adj_rent * renter_ins)
        result += adj_total
    return result

# Purchase Cost Calculations

# Down payment and loan amount
dp = home_price * down_pmt
loan_amt = home_price - dp

# Initial fees based on loan type and down payment
init_mort_ins = 0
mo_mort_ins = 0
init_va_ff = 0
USDA_fee = 0

# Loan-specific fee calculations
if loan_type == 'Conventional' and down_pmt < 0.2:
    mo_mort_ins = loan_amt * 0.01 / 12  # *** Improvement: Refine this estimate for better accuracy
elif loan_type == 'VA' and VA_ff:
    if down_pmt < 0.05:
        init_va_ff = loan_amt * 0.0215
    elif down_pmt < 0.1:
        init_va_ff = loan_amt * 0.015
    else:
        init_va_ff = loan_amt * 0.0125
elif loan_type == 'FHA':
    init_mort_ins = loan_amt * 0.0175
    mo_mort_ins = loan_amt * 0.0085 / 12
elif loan_type == 'USDA':
    init_mort_ins = loan_amt * 0.01
    USDA_fee = 0.0035 / 12

# Adjust loan amount if fees are not paid out-of-pocket
loan_amt += (init_va_ff + init_mort_ins if not fees_out_of_pocket else 0)

# Initial Payment Calculation
def initial_payment():
    """
    Calculate the total initial payment at home purchase, including down payment, closing costs, and any upfront fees.
    """
    cc = home_price * closing_cost
    return dp + cc + (init_va_ff + init_mort_ins if fees_out_of_pocket else 0)

# Annual Cost Calculations for Ownership
def annual_payments(yrs_owned):
    """
    Calculate annual ownership costs, including mortgage, tax, insurance, repairs, and HOA fees.
    """
    # Mortgage Payment
    mo_PI = npf.pmt(
            int_rate / 12, 
            term * 12, 
            -loan_amt
        ) if yrs_owned < term + 1 else 0

    # Property Tax, Insurance, and Other Costs
    assd_incr_actual = min(assd_incr_exp, inflation_exp)
    mo_tax = (prop_tax / 12) * (home_price * ((1 + assd_incr_actual) ** yrs_owned))
    mo_ins = (home_ins / 12) * (home_price * ((1 + inflation_exp) ** yrs_owned))
    mo_repairs = (home_repairs / 12) * (home_price * ((1 + inflation_exp) ** yrs_owned))
    mo_hoa = hoa * (1 + inflation_exp) ** yrs_owned

    # Remaining Principal Calculation for USDA fee
    remaining_principal = npf.fv(
        int_rate / 12, 
        yrs_owned * 12, 
        mo_PI, 
        -loan_amt
    )
    mo_USDA_fee = USDA_fee * remaining_principal

    # Total Monthly Cost
    tot_mo_cost = (mo_PI + 
                   mo_tax + 
                   mo_ins + 
                   mo_repairs + 
                   mo_hoa + 
                   mo_mort_ins + 
                   mo_USDA_fee
                   )

    return 12 * tot_mo_cost

def annual_ownership_cost(yrs_owned):
    tot_init_cost = initial_payment()
    return annual_payments(yrs_owned) + (tot_init_cost if yrs_owned == 0 else 0)

# Gross Cost Functions for Ownership
def gross_ownership_cost(yrs_owned):    
    """
    Calculate cumulative gross ownership cost over the years owned, adding initial costs and ongoing expenses.
    """
    tot_init_cost = initial_payment()
    result = tot_init_cost
    for i in range(yrs_owned):
        result += annual_payments(i)
    return result

# Sale Proceeds Calculations
def home_sale_proceeds(yrs_owned):
    """
    Calculate potential sale proceeds after accounting for capital gains tax, realtor fees, and other costs.
    """
    estimate_sale_price = home_price * ((1 + price_appr_exp) ** yrs_owned)
    scc = estimate_sale_price * closing_cost
    srf = estimate_sale_price * realtor_fee
    improvements = 0.50 * npf.fv(inflation_exp / 12, yrs_owned * 12, -home_price * home_repairs / 12, 0)

    # Capital Gains Tax Calculation
    cap_gains = estimate_sale_price - home_price - scc - srf - improvements
    cap_gains_tax = 0
    if yrs_owned < 1:
        cap_gains_tax = cap_gains * 0.22 # *** Refine based on actual income tax brackets
    elif yrs_owned < 2:
        cap_gains_tax = cap_gains * 0.15
    else:
        cap_gains_tax = (cap_gains - (250_000 * (married + 1))) * 0.15  

    cap_gains_tax = max(cap_gains_tax, 0)

    # Remaining Principal after Mortgage
    mo_PI = npf.pmt(
            int_rate / 12, 
            term * 12, 
            -loan_amt
        )
    remaining_principal = npf.fv(
        int_rate / 12, 
        yrs_owned * 12, 
        mo_PI, 
        -loan_amt
    )

    # Final Sale Proceeds
    result = estimate_sale_price - scc - srf - remaining_principal - cap_gains_tax
    return result, estimate_sale_price, improvements

def net_ownership_cost(yrs_owned):
    """
    Calculate the net ownership cost over a given number of years by subtracting
    the home sale proceeds from the gross ownership cost.
    """
    gross_cost = gross_ownership_cost(yrs_owned)
    sale_proceeds, _, _ = home_sale_proceeds(yrs_owned)  # Fetch sale proceeds from home sale function
    return gross_cost - sale_proceeds

# Calculate total cost values for the given time horizon
gr_rent = gross_rental_cost(time_horizon)  # Total gross rental cost over the time horizon
gr_own = gross_ownership_cost(time_horizon)  # Total gross ownership cost over the time horizon
net_own = net_ownership_cost(time_horizon)  # Net ownership cost after potential home sale proceeds
sale_profit = home_sale_proceeds(time_horizon)[0]  # Proceeds from selling the home
sale_price = home_sale_proceeds(time_horizon)[1]  # Estimated home sale price at the end of time horizon

# Create cumulative time-series dataframes for plotting
ub = time_horizon + 10  # Set upper bound for years (extends beyond time horizon for broader analysis)
years = np.arange(0, ub)  # Array of years for analysis

# Generate cumulative and annual cost lists over the years for rental and ownership costs
cum_rent = [gross_rental_cost(yr) for yr in years]
cum_gross_own = [gross_ownership_cost(yr) for yr in years]
cum_net_own = [net_ownership_cost(yr) for yr in years]
ann_rent = np.array([annual_rental_cost(yr) for yr in years])
ann_own = np.array([annual_ownership_cost(yr) for yr in years])

# Create DataFrame for annual costs and track extra cash from renting, then calculate invested returns
ann_df = pd.DataFrame({
    'Annual Rental Cost': ann_rent,
    'Annual Ownership Cost': ann_own,
    'Extra Cash From Renting': ann_own - ann_rent
}, index=years)
ann_df['Cumulative Delta'] = ann_df['Extra Cash From Renting'].cumsum()  # Track cumulative savings from renting
ann_df['Cumulative Invested Returns'] = ann_df['Extra Cash From Renting'].expanding().apply(
    lambda x: sum([v * (1 + invest_yield_exp) ** (len(x) - i - 1) for i, v in enumerate(x)]))

# Create DataFrame for cumulative gross and net costs for both renting and owning
cum_df = pd.DataFrame({
    'Cumulative Gross Rental Cost': cum_rent,
    'Cumulative Net Rental Cost': cum_rent - ann_df['Cumulative Invested Returns'],
    'Cumulative Gross Ownership Cost': cum_gross_own,
    'Cumulative Net Ownership Cost': cum_net_own
}, index=years)

def net_ownership_cost(yrs_owned):
    """
    Calculate the net ownership cost over a given number of years by subtracting
    the home sale proceeds from the gross ownership cost.
    """
    gross_cost = gross_ownership_cost(yrs_owned)
    sale_proceeds, _, _ = home_sale_proceeds(yrs_owned)  # Fetch sale proceeds from home sale function
    return gross_cost - sale_proceeds
# Net rental cost after investing the extra cash from renting
net_rent = cum_df['Cumulative Net Rental Cost'].iloc[time_horizon]

# Summary Output
print(f'''After {time_horizon} years:
Total gross rental cost: ${gr_rent:,.2f}
Total net rental cost, with offsetting invested returns: ${net_rent:,.2f}

Total gross ownership cost: ${gr_own:,.2f}
Estimated sale price: ${sale_price:,.2f}
Home sale proceeds: ${sale_profit:,.2f} 
Total net ownership cost, with home sale proceeds: ${net_own:,.2f}''')

# Define color scheme for plots
color_map = {
    'Cumulative Gross Rental Cost': '#00FF7F',
    'Cumulative Net Rental Cost': '#006400',
    'Cumulative Gross Ownership Cost': '#87CEEB',
    'Cumulative Net Ownership Cost': '#000080',
    'Annual Rental Cost': '#00FF7F',
    'Annual Ownership Cost': '#87CEEB',
    'Extra Cash From Renting': '#FFEB3B',
    'Cumulative Delta': '#FFA500',
    'Cumulative Invested Returns': '#FF4500'
}

# Plotting Cumulative Costs
plt.figure(figsize=(12, 6))
for cost in cum_df.columns:
    plt.plot(cum_df.index, cum_df[cost], label=cost, color=color_map[cost])

# Vertical line marking the time horizon
plt.axvline(x=time_horizon, color='black', linestyle='--', linewidth=1, label='Time Horizon')

# Annotation for final cumulative values at time horizon
plot_points = sorted([gr_rent, net_rent, gr_own, net_own], reverse=False)
y_offset = 2500 * ub  # Offset for annotations to avoid overlap
for i, plpt in enumerate(plot_points):
    fontweight = 'bold' if i == 0 else 'normal'
    plt.text(time_horizon, plpt + i * y_offset, f' ${plpt:,.0f}', 
             ha='left', va='top', color='black', fontsize=12, fontweight=fontweight)

# Labels and formatting
plt.xlabel('Years Completed')
plt.gca().xaxis.set_major_locator(mtick.MultipleLocator(1))
plt.ylabel('Cost')
plt.gca().yaxis.set_major_locator(mtick.MultipleLocator(100000))
plt.gca().yaxis.set_major_formatter(mtick.StrMethodFormatter('${x:,.0f}'))
plt.legend(title='Legend')
plt.title(f'Cumulative Cost of Renting vs Owning over {time_horizon} Years')
plt.gca().set_facecolor('#f0f0f0')
plt.gcf().set_facecolor('#d3d3d3')
plt.show()

# Plotting Annual Costs
plt.figure(figsize=(12, 6))
for cost in ann_df.columns:
    if 'Cumulative' not in cost:
        plt.plot(ann_df.index, ann_df[cost], label=cost, color=color_map[cost])

# Horizontal line at y=0 for reference
plt.axhline(y=0, color='black', linestyle='--', linewidth=1)

# Labels and formatting for annual cost plot
plt.xlabel('Years Completed')
plt.gca().xaxis.set_major_locator(mtick.MultipleLocator(1))
plt.ylabel('Cost')
plt.gca().yaxis.set_major_locator(mtick.MultipleLocator(5000))
plt.gca().yaxis.set_major_formatter(mtick.StrMethodFormatter('${x:,.0f}'))
plt.legend(title='Legend')
plt.title('Annual Cost of Renting vs Owning for Upcoming Year')
plt.gca().set_facecolor('#f0f0f0')
plt.gcf().set_facecolor('#d3d3d3')
plt.show()